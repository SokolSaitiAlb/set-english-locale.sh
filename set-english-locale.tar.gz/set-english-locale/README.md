# Set English Locale (en_US.UTF-8) Script

This script configures your Linux system to use the `en_US.UTF-8` locale system-wide, 
and optionally removes any existing Albanian (sq_*) locale settings.

## 🔧 What it does

1. Enables only the `en_US.UTF-8` locale in `/etc/locale.gen`.
2. Deletes any Albanian locale entries.
3. Runs `locale-gen` to regenerate locales.
4. Sets system-wide locale in `/etc/locale.conf`.
5. Cleans and sets persistent locale settings in your `.bashrc`.

## 📦 Usage

```bash
tar -xvf set-english-locale.tar.gz
cd set-english-locale
chmod +x set-english-locale.sh
sudo ./set-english-locale.sh
```

🛑 **Reboot your system** after running the script to fully apply locale changes.

## 📂 Files

- `set-english-locale.sh` — The main script.
- `README.md` — This file.

## ✅ Compatible with

- Arch Linux / CachyOS / Manjaro
- Any system using `locale.gen` and `locale.conf`
