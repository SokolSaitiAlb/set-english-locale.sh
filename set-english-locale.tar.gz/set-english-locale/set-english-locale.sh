#!/bin/bash

echo "🔧 Setting system locale to English (en_US.UTF-8)..."

# 1. Enable only en_US.UTF-8 in /etc/locale.gen
sudo sed -i 's/^#\s*\(en_US.UTF-8 UTF-8\)/\1/' /etc/locale.gen
sudo sed -i '/^sq_/d' /etc/locale.gen   # Remove Albanian locales if present
sudo sed -i '/^#.*sq_/d' /etc/locale.gen

# 2. Generate locales
sudo locale-gen

# 3. Set system-wide locale
sudo bash -c 'cat > /etc/locale.conf << EOF2
LANG=en_US.UTF-8
LC_ALL=en_US.UTF-8
EOF2'

# 4. Clean personal environment overrides (optional)
sed -i '/LC_/d' ~/.bashrc 2>/dev/null
sed -i '/LANG=/d' ~/.bashrc 2>/dev/null
echo "export LANG=en_US.UTF-8" >> ~/.bashrc
echo "export LC_ALL=en_US.UTF-8" >> ~/.bashrc

echo "✅ Locale successfully set to English (en_US.UTF-8). Please reboot."
